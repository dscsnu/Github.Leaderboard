var require = meteorInstall({"server":{"cron":{"refresh.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// server/cron/refresh.js                                                                                       //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let CronJob;
module.link("cron", {
  CronJob(v) {
    CronJob = v;
  }

}, 1);
let Participants;
module.link("../models/participants", {
  Participants(v) {
    Participants = v;
  }

}, 2);
let baseTimeStamp;
module.link("../../config", {
  baseTimeStamp(v) {
    baseTimeStamp = v;
  }

}, 3);
let fetch, Headers;
module.link("node-fetch", {
  default(v) {
    fetch = v;
  },

  Headers(v) {
    Headers = v;
  }

}, 4);
let config;
module.link("../../config", {
  default(v) {
    config = v;
  }

}, 5);
let githubAccessToken = process.env.githubAccessToken || config.githubAccessToken;

const perPerson = person => Promise.asyncApply(() => {
  let {
    username,
    lastContrib,
    commits,
    prs
  } = person;
  lastContrib = typeof lastContrib === 'number' ? lastContrib : 0;
  let temp = Promise.await(fetch("https://api.github.com/users/".concat(username), {
    headers: new Headers({
      'Authorization': "token ".concat(githubAccessToken)
    })
  }));
  temp = Promise.await(temp.json());
  let {
    avatar_url
  } = temp;

  try {
    let events = [];

    for (let i = 1; i <= 10; i++) {
      temp = Promise.await(fetch("https://api.github.com/users/".concat(username, "/events?page=").concat(i), {
        headers: new Headers({
          'Authorization': "token ".concat(githubAccessToken)
        })
      }));
      temp = Promise.await(temp.json());
      events = [...events, ...temp];
      if (temp.length > 0 && Date.parse(temp[temp.length - 1].created_at) < lastContrib) break;
    } //New Commits by user


    let newCommits = events.filter(event => Date.parse(event.created_at) > lastContrib);
    newCommits = newCommits.length == 0 ? [] : newCommits.reduce((val, elem) => {
      if (typeof val === 'number') {
        let temp = elem.type === 'PushEvent' ? elem.payload.commits.length : 0;
        return val + temp;
      } else {
        let temp1 = val.type === 'PushEvent' ? val.payload.commits.length : 0;
        let temp2 = elem.type === 'PushEvent' ? elem.payload.commits.length : 0;
        return temp1 + temp2;
      }
    });
    let newPRs = events.filter(event => Date.parse(event.created_at) > lastContrib && event.type === 'PullRequestEvent' && event.payload && event.payload.action && event.payload.action === 'opened').length;
    Participants.update({
      username: username
    }, {
      $set: {
        lastContrib: events[0] ? Date.parse(events[0].created_at) : lastContrib,
        commits: parseInt(commits) + parseInt(newCommits),
        prs: parseInt(prs) + parseInt(newPRs),
        avatar_url: avatar_url
      }
    });
  } catch (e) {
    console.log(e);
  }
});

const updateData = () => Promise.asyncApply(() => {
  const participantsList = Participants.find({}).fetch();

  for (part in participantsList) Promise.await(perPerson(participantsList[part]));
});

Meteor.startup(() => {
  new CronJob({
    cronTime: '00 00 00 * * *',
    // use this wrapper if you want to work with mongo:
    onTick: updateData,
    start: true,
    timeZone: 'Asia/Kolkata'
  }); //Participants.remove({});

  if (Participants.find({}).fetch().length < 1) {
    //Initialize the database: First launch
    for (part in config.participants) Participants.insert(config.participants[part]);
  }

  updateData();
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"models":{"participants.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// server/models/participants.js                                                                                //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
module.export({
  Participants: () => Participants
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
const Participants = new Mongo.Collection("participants");
//Do not allow updation from client
Meteor.methods({
  'participants.insert'(text) {
    throw new Meteor.Error('not-authorized');
  },

  'participants.update'(text) {
    throw new Meteor.Error('not-authorized');
  },

  'participants.delete'(text) {
    throw new Meteor.Error('not-authorized');
  },

  'participants.remove'(text) {
    throw new Meteor.Error('not-authorized');
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"main.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// server/main.js                                                                                               //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
module.link("./models/participants");
module.link("./cron/refresh");
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"config.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// config.js                                                                                                    //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
module.exportDefault({
  baseTimeStamp: 0,
  githubAccessToken: '10ff1e998d21690a0dbc36f9567e7976b46994db',
  participants: [{
    username: "ishitb",
    commits: 0,
    prs: 0,
    lastContrib: 0
  }, {
    username: "prkhrbhsn",
    commits: 0,
    prs: 0,
    lastContrib: 0
  }, {
    username: "siddharthborderwala",
    commits: 0,
    prs: 0,
    lastContrib: 0
  }, {
    username: "yasharma2301",
    commits: 0,
    prs: 0,
    lastContrib: 0
  }, {
    username: "tan-alpha",
    commits: 0,
    prs: 0,
    lastContrib: 0
  }, {
    username: "ayushvarma7",
    commits: 0,
    prs: 0,
    lastContrib: 0
  }, {
    username: "siddhantmittal024",
    commits: 0,
    prs: 0,
    lastContrib: 0
  }, {
    username: "aKn1ghtOut",
    commits: 0,
    prs: 0,
    lastContrib: 0
  }]
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},{
  "extensions": [
    ".js",
    ".json",
    ".mjs",
    ".ts"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2Nyb24vcmVmcmVzaC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21vZGVscy9wYXJ0aWNpcGFudHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb25maWcuanMiXSwibmFtZXMiOlsiTWV0ZW9yIiwibW9kdWxlIiwibGluayIsInYiLCJDcm9uSm9iIiwiUGFydGljaXBhbnRzIiwiYmFzZVRpbWVTdGFtcCIsImZldGNoIiwiSGVhZGVycyIsImRlZmF1bHQiLCJjb25maWciLCJnaXRodWJBY2Nlc3NUb2tlbiIsInByb2Nlc3MiLCJlbnYiLCJwZXJQZXJzb24iLCJwZXJzb24iLCJ1c2VybmFtZSIsImxhc3RDb250cmliIiwiY29tbWl0cyIsInBycyIsInRlbXAiLCJoZWFkZXJzIiwianNvbiIsImF2YXRhcl91cmwiLCJldmVudHMiLCJpIiwibGVuZ3RoIiwiRGF0ZSIsInBhcnNlIiwiY3JlYXRlZF9hdCIsIm5ld0NvbW1pdHMiLCJmaWx0ZXIiLCJldmVudCIsInJlZHVjZSIsInZhbCIsImVsZW0iLCJ0eXBlIiwicGF5bG9hZCIsInRlbXAxIiwidGVtcDIiLCJuZXdQUnMiLCJhY3Rpb24iLCJ1cGRhdGUiLCIkc2V0IiwicGFyc2VJbnQiLCJlIiwiY29uc29sZSIsImxvZyIsInVwZGF0ZURhdGEiLCJwYXJ0aWNpcGFudHNMaXN0IiwiZmluZCIsInBhcnQiLCJzdGFydHVwIiwiY3JvblRpbWUiLCJvblRpY2siLCJzdGFydCIsInRpbWVab25lIiwicGFydGljaXBhbnRzIiwiaW5zZXJ0IiwiZXhwb3J0IiwiTW9uZ28iLCJDb2xsZWN0aW9uIiwibWV0aG9kcyIsInRleHQiLCJFcnJvciIsImV4cG9ydERlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsSUFBSUEsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxPQUFKO0FBQVlILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLE1BQVosRUFBbUI7QUFBQ0UsU0FBTyxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsV0FBTyxHQUFDRCxDQUFSO0FBQVU7O0FBQXRCLENBQW5CLEVBQTJDLENBQTNDO0FBQThDLElBQUlFLFlBQUo7QUFBaUJKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHdCQUFaLEVBQXFDO0FBQUNHLGNBQVksQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGdCQUFZLEdBQUNGLENBQWI7QUFBZTs7QUFBaEMsQ0FBckMsRUFBdUUsQ0FBdkU7QUFBMEUsSUFBSUcsYUFBSjtBQUFrQkwsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDSSxlQUFhLENBQUNILENBQUQsRUFBRztBQUFDRyxpQkFBYSxHQUFDSCxDQUFkO0FBQWdCOztBQUFsQyxDQUEzQixFQUErRCxDQUEvRDtBQUFrRSxJQUFJSSxLQUFKLEVBQVVDLE9BQVY7QUFBa0JQLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFlBQVosRUFBeUI7QUFBQ08sU0FBTyxDQUFDTixDQUFELEVBQUc7QUFBQ0ksU0FBSyxHQUFDSixDQUFOO0FBQVEsR0FBcEI7O0FBQXFCSyxTQUFPLENBQUNMLENBQUQsRUFBRztBQUFDSyxXQUFPLEdBQUNMLENBQVI7QUFBVTs7QUFBMUMsQ0FBekIsRUFBcUUsQ0FBckU7QUFBd0UsSUFBSU8sTUFBSjtBQUFXVCxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNPLFNBQU8sQ0FBQ04sQ0FBRCxFQUFHO0FBQUNPLFVBQU0sR0FBQ1AsQ0FBUDtBQUFTOztBQUFyQixDQUEzQixFQUFrRCxDQUFsRDtBQU85WSxJQUFJUSxpQkFBaUIsR0FBR0MsT0FBTyxDQUFDQyxHQUFSLENBQVlGLGlCQUFaLElBQWlDRCxNQUFNLENBQUNDLGlCQUFoRTs7QUFFQSxNQUFNRyxTQUFTLEdBQVNDLE1BQU4sNkJBQWdCO0FBQzlCLE1BQUk7QUFBQ0MsWUFBRDtBQUFXQyxlQUFYO0FBQXdCQyxXQUF4QjtBQUFpQ0M7QUFBakMsTUFBd0NKLE1BQTVDO0FBQ0FFLGFBQVcsR0FBRyxPQUFPQSxXQUFQLEtBQXdCLFFBQXhCLEdBQW1DQSxXQUFuQyxHQUFpRCxDQUEvRDtBQUNBLE1BQUlHLElBQUksaUJBQVNiLEtBQUssd0NBQ2NTLFFBRGQsR0FFbEI7QUFDSUssV0FBTyxFQUFFLElBQUliLE9BQUosQ0FBWTtBQUNqQix1Q0FBMEJHLGlCQUExQjtBQURpQixLQUFaO0FBRGIsR0FGa0IsQ0FBZCxDQUFSO0FBUUFTLE1BQUksaUJBQVNBLElBQUksQ0FBQ0UsSUFBTCxFQUFULENBQUo7QUFDQSxNQUFJO0FBQUVDO0FBQUYsTUFBaUJILElBQXJCOztBQUNBLE1BQUk7QUFDQSxRQUFJSSxNQUFNLEdBQUcsRUFBYjs7QUFFQSxTQUFJLElBQUlDLENBQUMsR0FBRyxDQUFaLEVBQWVBLENBQUMsSUFBSSxFQUFwQixFQUF3QkEsQ0FBQyxFQUF6QixFQUNBO0FBQ0lMLFVBQUksaUJBQVNiLEtBQUssd0NBQ2tCUyxRQURsQiwwQkFDMENTLENBRDFDLEdBRWQ7QUFDSUosZUFBTyxFQUFFLElBQUliLE9BQUosQ0FBWTtBQUNqQiwyQ0FBMEJHLGlCQUExQjtBQURpQixTQUFaO0FBRGIsT0FGYyxDQUFkLENBQUo7QUFRQVMsVUFBSSxpQkFBU0EsSUFBSSxDQUFDRSxJQUFMLEVBQVQsQ0FBSjtBQUNBRSxZQUFNLEdBQUcsQ0FBQyxHQUFHQSxNQUFKLEVBQVksR0FBR0osSUFBZixDQUFUO0FBQ0EsVUFBR0EsSUFBSSxDQUFDTSxNQUFMLEdBQWMsQ0FBZCxJQUFtQkMsSUFBSSxDQUFDQyxLQUFMLENBQVdSLElBQUksQ0FBQ0EsSUFBSSxDQUFDTSxNQUFMLEdBQWMsQ0FBZixDQUFKLENBQXNCRyxVQUFqQyxJQUErQ1osV0FBckUsRUFDQTtBQUNILEtBakJELENBbUJBOzs7QUFDQSxRQUFJYSxVQUFVLEdBQUdOLE1BQU0sQ0FBQ08sTUFBUCxDQUFjQyxLQUFLLElBQUlMLElBQUksQ0FBQ0MsS0FBTCxDQUFXSSxLQUFLLENBQUNILFVBQWpCLElBQStCWixXQUF0RCxDQUFqQjtBQUNBYSxjQUFVLEdBQUdBLFVBQVUsQ0FBQ0osTUFBWCxJQUFxQixDQUFyQixHQUF5QixFQUF6QixHQUE4QkksVUFBVSxDQUFDRyxNQUFYLENBQWtCLENBQUNDLEdBQUQsRUFBTUMsSUFBTixLQUFlO0FBQ3hFLFVBQUcsT0FBT0QsR0FBUCxLQUFnQixRQUFuQixFQUNBO0FBQ0ksWUFBSWQsSUFBSSxHQUFHZSxJQUFJLENBQUNDLElBQUwsS0FBYyxXQUFkLEdBQTRCRCxJQUFJLENBQUNFLE9BQUwsQ0FBYW5CLE9BQWIsQ0FBcUJRLE1BQWpELEdBQTBELENBQXJFO0FBQ0EsZUFBT1EsR0FBRyxHQUFHZCxJQUFiO0FBQ0gsT0FKRCxNQU1BO0FBQ0ksWUFBSWtCLEtBQUssR0FBR0osR0FBRyxDQUFDRSxJQUFKLEtBQWEsV0FBYixHQUEyQkYsR0FBRyxDQUFDRyxPQUFKLENBQVluQixPQUFaLENBQW9CUSxNQUEvQyxHQUF3RCxDQUFwRTtBQUNBLFlBQUlhLEtBQUssR0FBR0osSUFBSSxDQUFDQyxJQUFMLEtBQWMsV0FBZCxHQUE0QkQsSUFBSSxDQUFDRSxPQUFMLENBQWFuQixPQUFiLENBQXFCUSxNQUFqRCxHQUEwRCxDQUF0RTtBQUNBLGVBQU9ZLEtBQUssR0FBR0MsS0FBZjtBQUNIO0FBQ0osS0FaMEMsQ0FBM0M7QUFhQSxRQUFJQyxNQUFNLEdBQUdoQixNQUFNLENBQUNPLE1BQVAsQ0FBY0MsS0FBSyxJQUFLTCxJQUFJLENBQUNDLEtBQUwsQ0FBV0ksS0FBSyxDQUFDSCxVQUFqQixJQUErQlosV0FBL0IsSUFBOENlLEtBQUssQ0FBQ0ksSUFBTixLQUFlLGtCQUE3RCxJQUFtRkosS0FBSyxDQUFDSyxPQUF6RixJQUFvR0wsS0FBSyxDQUFDSyxPQUFOLENBQWNJLE1BQWxILElBQTRIVCxLQUFLLENBQUNLLE9BQU4sQ0FBY0ksTUFBZCxLQUF5QixRQUE3SyxFQUF3TGYsTUFBck07QUFDQXJCLGdCQUFZLENBQUNxQyxNQUFiLENBQ0k7QUFBRTFCLGNBQVEsRUFBR0E7QUFBYixLQURKLEVBRUk7QUFDSTJCLFVBQUksRUFBRTtBQUNGMUIsbUJBQVcsRUFBRU8sTUFBTSxDQUFDLENBQUQsQ0FBTixHQUFZRyxJQUFJLENBQUNDLEtBQUwsQ0FBWUosTUFBTSxDQUFDLENBQUQsQ0FBTixDQUFVSyxVQUF0QixDQUFaLEdBQWlEWixXQUQ1RDtBQUVGQyxlQUFPLEVBQUUwQixRQUFRLENBQUMxQixPQUFELENBQVIsR0FBb0IwQixRQUFRLENBQUNkLFVBQUQsQ0FGbkM7QUFHRlgsV0FBRyxFQUFFeUIsUUFBUSxDQUFDekIsR0FBRCxDQUFSLEdBQWdCeUIsUUFBUSxDQUFDSixNQUFELENBSDNCO0FBSUZqQixrQkFBVSxFQUFFQTtBQUpWO0FBRFYsS0FGSjtBQVdILEdBOUNELENBK0NBLE9BQU1zQixDQUFOLEVBQVE7QUFDSkMsV0FBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKLENBL0RpQixDQUFsQjs7QUFpRUEsTUFBTUcsVUFBVSxHQUFHLCtCQUFZO0FBQzNCLFFBQU1DLGdCQUFnQixHQUFHNUMsWUFBWSxDQUFDNkMsSUFBYixDQUFrQixFQUFsQixFQUFzQjNDLEtBQXRCLEVBQXpCOztBQUNBLE9BQUk0QyxJQUFKLElBQVlGLGdCQUFaLEVBQ0ksY0FBTW5DLFNBQVMsQ0FBQ21DLGdCQUFnQixDQUFDRSxJQUFELENBQWpCLENBQWY7QUFDUCxDQUprQixDQUFuQjs7QUFNQW5ELE1BQU0sQ0FBQ29ELE9BQVAsQ0FBZSxNQUFNO0FBQ2pCLE1BQUloRCxPQUFKLENBQVk7QUFDUmlELFlBQVEsRUFBRSxnQkFERjtBQUVSO0FBQ0FDLFVBQU0sRUFBRU4sVUFIQTtBQUlSTyxTQUFLLEVBQUUsSUFKQztBQUtSQyxZQUFRLEVBQUU7QUFMRixHQUFaLEVBRGlCLENBUWpCOztBQUNBLE1BQUduRCxZQUFZLENBQUM2QyxJQUFiLENBQWtCLEVBQWxCLEVBQXNCM0MsS0FBdEIsR0FBOEJtQixNQUE5QixHQUF1QyxDQUExQyxFQUE0QztBQUN4QztBQUNBLFNBQUl5QixJQUFKLElBQVl6QyxNQUFNLENBQUMrQyxZQUFuQixFQUNJcEQsWUFBWSxDQUFDcUQsTUFBYixDQUFvQmhELE1BQU0sQ0FBQytDLFlBQVAsQ0FBb0JOLElBQXBCLENBQXBCO0FBQ1A7O0FBQ0RILFlBQVU7QUFDYixDQWZELEU7Ozs7Ozs7Ozs7O0FDaEZBL0MsTUFBTSxDQUFDMEQsTUFBUCxDQUFjO0FBQUN0RCxjQUFZLEVBQUMsTUFBSUE7QUFBbEIsQ0FBZDtBQUErQyxJQUFJTCxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUl5RCxLQUFKO0FBQVUzRCxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUMwRCxPQUFLLENBQUN6RCxDQUFELEVBQUc7QUFBQ3lELFNBQUssR0FBQ3pELENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFHbEgsTUFBTUUsWUFBWSxHQUFHLElBQUl1RCxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsY0FBckIsQ0FBckI7QUFFUDtBQUNBN0QsTUFBTSxDQUFDOEQsT0FBUCxDQUFlO0FBQ1gsd0JBQXNCQyxJQUF0QixFQUEyQjtBQUN2QixVQUFNLElBQUkvRCxNQUFNLENBQUNnRSxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0gsR0FIVTs7QUFJWCx3QkFBc0JELElBQXRCLEVBQTJCO0FBQ3ZCLFVBQU0sSUFBSS9ELE1BQU0sQ0FBQ2dFLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDSCxHQU5VOztBQU9YLHdCQUFzQkQsSUFBdEIsRUFBMkI7QUFDdkIsVUFBTSxJQUFJL0QsTUFBTSxDQUFDZ0UsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNILEdBVFU7O0FBVVgsd0JBQXNCRCxJQUF0QixFQUEyQjtBQUN2QixVQUFNLElBQUkvRCxNQUFNLENBQUNnRSxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0g7O0FBWlUsQ0FBZixFOzs7Ozs7Ozs7OztBQ05BLElBQUloRSxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFERixNQUFNLENBQUNDLElBQVAsQ0FBWSx1QkFBWjtBQUFxQ0QsTUFBTSxDQUFDQyxJQUFQLENBQVksZ0JBQVosRTs7Ozs7Ozs7Ozs7QUNBckdELE1BQU0sQ0FBQ2dFLGFBQVAsQ0FBZTtBQUNYM0QsZUFBYSxFQUFFLENBREo7QUFFWEssbUJBQWlCLEVBQUUsMENBRlI7QUFHWDhDLGNBQVksRUFBRSxDQUNWO0FBQ0l6QyxZQUFRLEVBQUUsUUFEZDtBQUVJRSxXQUFPLEVBQUUsQ0FGYjtBQUdJQyxPQUFHLEVBQUUsQ0FIVDtBQUlJRixlQUFXLEVBQUU7QUFKakIsR0FEVSxFQU9WO0FBQ0lELFlBQVEsRUFBRSxXQURkO0FBRUlFLFdBQU8sRUFBRSxDQUZiO0FBR0lDLE9BQUcsRUFBRSxDQUhUO0FBSUlGLGVBQVcsRUFBRTtBQUpqQixHQVBVLEVBYVY7QUFDSUQsWUFBUSxFQUFFLHFCQURkO0FBRUlFLFdBQU8sRUFBRSxDQUZiO0FBR0lDLE9BQUcsRUFBRSxDQUhUO0FBSUlGLGVBQVcsRUFBRTtBQUpqQixHQWJVLEVBbUJWO0FBQ0lELFlBQVEsRUFBRSxjQURkO0FBRUlFLFdBQU8sRUFBRSxDQUZiO0FBR0lDLE9BQUcsRUFBRSxDQUhUO0FBSUlGLGVBQVcsRUFBRTtBQUpqQixHQW5CVSxFQXlCVjtBQUNJRCxZQUFRLEVBQUUsV0FEZDtBQUVJRSxXQUFPLEVBQUUsQ0FGYjtBQUdJQyxPQUFHLEVBQUUsQ0FIVDtBQUlJRixlQUFXLEVBQUU7QUFKakIsR0F6QlUsRUErQlY7QUFDSUQsWUFBUSxFQUFFLGFBRGQ7QUFFSUUsV0FBTyxFQUFFLENBRmI7QUFHSUMsT0FBRyxFQUFFLENBSFQ7QUFJSUYsZUFBVyxFQUFFO0FBSmpCLEdBL0JVLEVBcUNWO0FBQ0lELFlBQVEsRUFBRSxtQkFEZDtBQUVJRSxXQUFPLEVBQUUsQ0FGYjtBQUdJQyxPQUFHLEVBQUUsQ0FIVDtBQUlJRixlQUFXLEVBQUU7QUFKakIsR0FyQ1UsRUEyQ1Y7QUFDSUQsWUFBUSxFQUFFLFlBRGQ7QUFFSUUsV0FBTyxFQUFFLENBRmI7QUFHSUMsT0FBRyxFQUFFLENBSFQ7QUFJSUYsZUFBVyxFQUFFO0FBSmpCLEdBM0NVO0FBSEgsQ0FBZixFIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IENyb25Kb2IgfSBmcm9tICdjcm9uJztcbmltcG9ydCB7IFBhcnRpY2lwYW50cyB9IGZyb20gJy4uL21vZGVscy9wYXJ0aWNpcGFudHMnO1xuaW1wb3J0IHsgYmFzZVRpbWVTdGFtcCB9IGZyb20gJy4uLy4uL2NvbmZpZyc7XG5pbXBvcnQgZmV0Y2gsIHsgSGVhZGVycyB9IGZyb20gJ25vZGUtZmV0Y2gnO1xuaW1wb3J0IGNvbmZpZyBmcm9tICcuLi8uLi9jb25maWcnO1xuXG5sZXQgZ2l0aHViQWNjZXNzVG9rZW4gPSBwcm9jZXNzLmVudi5naXRodWJBY2Nlc3NUb2tlbiB8fCBjb25maWcuZ2l0aHViQWNjZXNzVG9rZW47XG5cbmNvbnN0IHBlclBlcnNvbiA9IGFzeW5jIHBlcnNvbiA9PiB7XG4gICAgbGV0IHt1c2VybmFtZSwgbGFzdENvbnRyaWIsIGNvbW1pdHMsIHByc30gPSBwZXJzb247XG4gICAgbGFzdENvbnRyaWIgPSB0eXBlb2YobGFzdENvbnRyaWIpID09PSAnbnVtYmVyJyA/IGxhc3RDb250cmliIDogMDtcbiAgICBsZXQgdGVtcCA9IGF3YWl0IGZldGNoKFxuICAgICAgICBgaHR0cHM6Ly9hcGkuZ2l0aHViLmNvbS91c2Vycy8ke3VzZXJuYW1lfWAsXG4gICAgICAgIHtcbiAgICAgICAgICAgIGhlYWRlcnM6IG5ldyBIZWFkZXJzKHtcbiAgICAgICAgICAgICAgICAnQXV0aG9yaXphdGlvbic6IGB0b2tlbiAke2dpdGh1YkFjY2Vzc1Rva2VufWBcbiAgICAgICAgICAgIH0pXG4gICAgICAgIH1cbiAgICApO1xuICAgIHRlbXAgPSBhd2FpdCB0ZW1wLmpzb24oKTtcbiAgICBsZXQgeyBhdmF0YXJfdXJsIH0gPSB0ZW1wO1xuICAgIHRyeSB7XG4gICAgICAgIGxldCBldmVudHMgPSBbXTtcblxuICAgICAgICBmb3IobGV0IGkgPSAxOyBpIDw9IDEwOyBpKyspXG4gICAgICAgIHtcbiAgICAgICAgICAgIHRlbXAgPSBhd2FpdCBmZXRjaChcbiAgICAgICAgICAgICAgICBgaHR0cHM6Ly9hcGkuZ2l0aHViLmNvbS91c2Vycy8ke3VzZXJuYW1lfS9ldmVudHM/cGFnZT0ke2l9YCxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGhlYWRlcnM6IG5ldyBIZWFkZXJzKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogYHRva2VuICR7Z2l0aHViQWNjZXNzVG9rZW59YFxuICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICB0ZW1wID0gYXdhaXQgdGVtcC5qc29uKCk7XG4gICAgICAgICAgICBldmVudHMgPSBbLi4uZXZlbnRzLCAuLi50ZW1wXTtcbiAgICAgICAgICAgIGlmKHRlbXAubGVuZ3RoID4gMCAmJiBEYXRlLnBhcnNlKHRlbXBbdGVtcC5sZW5ndGggLSAxXS5jcmVhdGVkX2F0KSA8IGxhc3RDb250cmliKVxuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cblxuICAgICAgICAvL05ldyBDb21taXRzIGJ5IHVzZXJcbiAgICAgICAgbGV0IG5ld0NvbW1pdHMgPSBldmVudHMuZmlsdGVyKGV2ZW50ID0+IERhdGUucGFyc2UoZXZlbnQuY3JlYXRlZF9hdCkgPiBsYXN0Q29udHJpYik7XG4gICAgICAgIG5ld0NvbW1pdHMgPSBuZXdDb21taXRzLmxlbmd0aCA9PSAwID8gW10gOiBuZXdDb21taXRzLnJlZHVjZSgodmFsLCBlbGVtKSA9PiB7XG4gICAgICAgICAgICBpZih0eXBlb2YodmFsKSA9PT0gJ251bWJlcicpXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgbGV0IHRlbXAgPSBlbGVtLnR5cGUgPT09ICdQdXNoRXZlbnQnID8gZWxlbS5wYXlsb2FkLmNvbW1pdHMubGVuZ3RoIDogMDtcbiAgICAgICAgICAgICAgICByZXR1cm4gdmFsICsgdGVtcDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBsZXQgdGVtcDEgPSB2YWwudHlwZSA9PT0gJ1B1c2hFdmVudCcgPyB2YWwucGF5bG9hZC5jb21taXRzLmxlbmd0aCA6IDA7XG4gICAgICAgICAgICAgICAgbGV0IHRlbXAyID0gZWxlbS50eXBlID09PSAnUHVzaEV2ZW50JyA/IGVsZW0ucGF5bG9hZC5jb21taXRzLmxlbmd0aCA6IDA7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRlbXAxICsgdGVtcDI7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICBsZXQgbmV3UFJzID0gZXZlbnRzLmZpbHRlcihldmVudCA9PiAoRGF0ZS5wYXJzZShldmVudC5jcmVhdGVkX2F0KSA+IGxhc3RDb250cmliICYmIGV2ZW50LnR5cGUgPT09ICdQdWxsUmVxdWVzdEV2ZW50JyAmJiBldmVudC5wYXlsb2FkICYmIGV2ZW50LnBheWxvYWQuYWN0aW9uICYmIGV2ZW50LnBheWxvYWQuYWN0aW9uID09PSAnb3BlbmVkJykpLmxlbmd0aDtcbiAgICAgICAgUGFydGljaXBhbnRzLnVwZGF0ZShcbiAgICAgICAgICAgIHsgdXNlcm5hbWUgOiB1c2VybmFtZSB9LFxuICAgICAgICAgICAgeyBcbiAgICAgICAgICAgICAgICAkc2V0OiB7XG4gICAgICAgICAgICAgICAgICAgIGxhc3RDb250cmliOiBldmVudHNbMF0gPyBEYXRlLnBhcnNlKCBldmVudHNbMF0uY3JlYXRlZF9hdCApIDogbGFzdENvbnRyaWIsXG4gICAgICAgICAgICAgICAgICAgIGNvbW1pdHM6IHBhcnNlSW50KGNvbW1pdHMpICsgcGFyc2VJbnQobmV3Q29tbWl0cyksXG4gICAgICAgICAgICAgICAgICAgIHByczogcGFyc2VJbnQocHJzKSArIHBhcnNlSW50KG5ld1BScyksXG4gICAgICAgICAgICAgICAgICAgIGF2YXRhcl91cmw6IGF2YXRhcl91cmxcbiAgICAgICAgICAgICAgICB9IFxuICAgICAgICAgICAgfVxuICAgICAgICApO1xuICAgIH1cbiAgICBjYXRjaChlKXtcbiAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgfVxufVxuXG5jb25zdCB1cGRhdGVEYXRhID0gYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHBhcnRpY2lwYW50c0xpc3QgPSBQYXJ0aWNpcGFudHMuZmluZCh7fSkuZmV0Y2goKTtcbiAgICBmb3IocGFydCBpbiBwYXJ0aWNpcGFudHNMaXN0KVxuICAgICAgICBhd2FpdCBwZXJQZXJzb24ocGFydGljaXBhbnRzTGlzdFtwYXJ0XSk7XG59XG5cbk1ldGVvci5zdGFydHVwKCgpID0+IHtcbiAgICBuZXcgQ3JvbkpvYih7XG4gICAgICAgIGNyb25UaW1lOiAnMDAgMDAgMDAgKiAqIConLFxuICAgICAgICAvLyB1c2UgdGhpcyB3cmFwcGVyIGlmIHlvdSB3YW50IHRvIHdvcmsgd2l0aCBtb25nbzpcbiAgICAgICAgb25UaWNrOiB1cGRhdGVEYXRhLFxuICAgICAgICBzdGFydDogdHJ1ZSxcbiAgICAgICAgdGltZVpvbmU6ICdBc2lhL0tvbGthdGEnLFxuICAgIH0pO1xuICAgIC8vUGFydGljaXBhbnRzLnJlbW92ZSh7fSk7XG4gICAgaWYoUGFydGljaXBhbnRzLmZpbmQoe30pLmZldGNoKCkubGVuZ3RoIDwgMSl7XG4gICAgICAgIC8vSW5pdGlhbGl6ZSB0aGUgZGF0YWJhc2U6IEZpcnN0IGxhdW5jaFxuICAgICAgICBmb3IocGFydCBpbiBjb25maWcucGFydGljaXBhbnRzKVxuICAgICAgICAgICAgUGFydGljaXBhbnRzLmluc2VydChjb25maWcucGFydGljaXBhbnRzW3BhcnRdKTtcbiAgICB9XG4gICAgdXBkYXRlRGF0YSgpO1xufSk7IiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cbmV4cG9ydCBjb25zdCBQYXJ0aWNpcGFudHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbihcInBhcnRpY2lwYW50c1wiKTtcblxuLy9EbyBub3QgYWxsb3cgdXBkYXRpb24gZnJvbSBjbGllbnRcbk1ldGVvci5tZXRob2RzKHtcbiAgICAncGFydGljaXBhbnRzLmluc2VydCcodGV4dCl7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG4gICAgfSxcbiAgICAncGFydGljaXBhbnRzLnVwZGF0ZScodGV4dCl7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG4gICAgfSxcbiAgICAncGFydGljaXBhbnRzLmRlbGV0ZScodGV4dCl7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG4gICAgfSxcbiAgICAncGFydGljaXBhbnRzLnJlbW92ZScodGV4dCl7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG4gICAgfVxufSkiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcblxuaW1wb3J0ICcuL21vZGVscy9wYXJ0aWNpcGFudHMnO1xuXG5pbXBvcnQgJy4vY3Jvbi9yZWZyZXNoJzsiLCJleHBvcnQgZGVmYXVsdCB7XG4gICAgYmFzZVRpbWVTdGFtcDogMCxcbiAgICBnaXRodWJBY2Nlc3NUb2tlbjogJzEwZmYxZTk5OGQyMTY5MGEwZGJjMzZmOTU2N2U3OTc2YjQ2OTk0ZGInLFxuICAgIHBhcnRpY2lwYW50czogW1xuICAgICAgICB7XG4gICAgICAgICAgICB1c2VybmFtZTogXCJpc2hpdGJcIixcbiAgICAgICAgICAgIGNvbW1pdHM6IDAsXG4gICAgICAgICAgICBwcnM6IDAsXG4gICAgICAgICAgICBsYXN0Q29udHJpYjogMFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgICB1c2VybmFtZTogXCJwcmtocmJoc25cIixcbiAgICAgICAgICAgIGNvbW1pdHM6IDAsXG4gICAgICAgICAgICBwcnM6IDAsXG4gICAgICAgICAgICBsYXN0Q29udHJpYjogMFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgICB1c2VybmFtZTogXCJzaWRkaGFydGhib3JkZXJ3YWxhXCIsXG4gICAgICAgICAgICBjb21taXRzOiAwLFxuICAgICAgICAgICAgcHJzOiAwLFxuICAgICAgICAgICAgbGFzdENvbnRyaWI6IDBcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgICAgdXNlcm5hbWU6IFwieWFzaGFybWEyMzAxXCIsXG4gICAgICAgICAgICBjb21taXRzOiAwLFxuICAgICAgICAgICAgcHJzOiAwLFxuICAgICAgICAgICAgbGFzdENvbnRyaWI6IDBcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgICAgdXNlcm5hbWU6IFwidGFuLWFscGhhXCIsXG4gICAgICAgICAgICBjb21taXRzOiAwLFxuICAgICAgICAgICAgcHJzOiAwLFxuICAgICAgICAgICAgbGFzdENvbnRyaWI6IDBcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgICAgdXNlcm5hbWU6IFwiYXl1c2h2YXJtYTdcIixcbiAgICAgICAgICAgIGNvbW1pdHM6IDAsXG4gICAgICAgICAgICBwcnM6IDAsXG4gICAgICAgICAgICBsYXN0Q29udHJpYjogMFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgICB1c2VybmFtZTogXCJzaWRkaGFudG1pdHRhbDAyNFwiLFxuICAgICAgICAgICAgY29tbWl0czogMCxcbiAgICAgICAgICAgIHByczogMCxcbiAgICAgICAgICAgIGxhc3RDb250cmliOiAwXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICAgIHVzZXJuYW1lOiBcImFLbjFnaHRPdXRcIixcbiAgICAgICAgICAgIGNvbW1pdHM6IDAsXG4gICAgICAgICAgICBwcnM6IDAsXG4gICAgICAgICAgICBsYXN0Q29udHJpYjogMFxuICAgICAgICB9XG4gICAgXVxufSJdfQ==

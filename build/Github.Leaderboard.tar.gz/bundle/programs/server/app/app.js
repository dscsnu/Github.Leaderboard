var require = meteorInstall({"server":{"cron":{"refresh.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/cron/refresh.js                                                                                           //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let CronJob;
module.link("cron", {
  CronJob(v) {
    CronJob = v;
  }

}, 1);
let Participants;
module.link("../models/participants", {
  Participants(v) {
    Participants = v;
  }

}, 2);
let baseTimeStamp;
module.link("../../config", {
  baseTimeStamp(v) {
    baseTimeStamp = v;
  }

}, 3);
let fetch, Headers;
module.link("node-fetch", {
  default(v) {
    fetch = v;
  },

  Headers(v) {
    Headers = v;
  }

}, 4);
let config;
module.link("../../config", {
  default(v) {
    config = v;
  }

}, 5);

const perPerson = person => Promise.asyncApply(() => {
  let {
    username,
    lastContrib,
    commits,
    prs
  } = person;
  lastContrib = typeof lastContrib === 'number' ? lastContrib : 0;

  try {
    let events = [];

    for (let i = 1; i <= 10; i++) {
      let temp = Promise.await(fetch("https://api.github.com/users/".concat(username, "/events?page=").concat(i), {
        headers: new Headers({
          'Authorization': "token ".concat(config.githubAccessToken)
        })
      }));
      temp = Promise.await(temp.json());
      events = [...events, ...temp];
      if (temp.length > 0 && Date.parse(temp[temp.length - 1].created_at) < lastContrib) break;
    }

    let firstPushEvent = events.find(event => event.type === 'PushEvent' && Date.parse(event.created_at) > baseTimeStamp); //New Commits by user

    let newCommits = events.filter(event => Date.parse(event.created_at) > lastContrib);
    newCommits = newCommits.length == 0 ? [] : newCommits.reduce((val, elem) => {
      if (typeof val === 'number') {
        let temp = elem.type === 'PushEvent' ? elem.payload.commits.length : 0;
        return val + temp;
      } else {
        let temp1 = val.type === 'PushEvent' ? val.payload.commits.length : 0;
        let temp2 = elem.type === 'PushEvent' ? elem.payload.commits.length : 0;
        return temp1 + temp2;
      }
    });
    let newPRs = events.filter(event => event.type === 'PullRequestEvent' && event.payload && event.payload.action && event.payload.action === 'opened').length;
    let output = Participants.update({
      username: username
    }, {
      $set: {
        lastContrib: events[0] && Date.parse(events[0].created_at) || lastContrib || 0,
        commits: commits && commits + newCommits || 0,
        prs: prs && prs + newPRs || 0
      }
    });
  } catch (e) {
    console.log(e);
  }
});

const updateData = () => Promise.asyncApply(() => {
  const participantsList = Participants.find({}).fetch();
  console.log(participantsList);

  for (part in participantsList) {
    Promise.await(perPerson(participantsList[part]));
  }
});

Meteor.startup(() => {
  new CronJob({
    cronTime: '00 00 00 * * *',
    // use this wrapper if you want to work with mongo:
    onTick: updateData,
    start: true,
    timeZone: 'Asia/Kolkata'
  });
  updateData();
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"models":{"participants.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/models/participants.js                                                                                    //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  Participants: () => Participants
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
const Participants = new Mongo.Collection("participants");
//Do not allow updation from client
Meteor.methods({
  'participants.insert'(text) {
    throw new Meteor.Error('not-authorized');
  },

  'participants.update'(text) {
    throw new Meteor.Error('not-authorized');
  },

  'participants.delete'(text) {
    throw new Meteor.Error('not-authorized');
  },

  'participants.remove'(text) {
    throw new Meteor.Error('not-authorized');
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"main.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/main.js                                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
module.link("./models/participants");
module.link("./cron/refresh");
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"config.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// config.js                                                                                                        //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.exportDefault({
  baseTimeStamp: 0,
  githubAccessToken: '10ff1e998d21690a0dbc36f9567e7976b46994db',
  participants: [{
    username: "ishitb",
    commits: 0,
    prs: 0,
    lastContrib: 0
  }, {
    username: "prkhrbhsn",
    commits: 0,
    prs: 0,
    lastContrib: 0
  }, {
    username: "siddharthborderwala",
    commits: 0,
    prs: 0,
    lastContrib: 0
  }, {
    username: "yasharma2301",
    commits: 0,
    prs: 0,
    lastContrib: 0
  }, {
    username: "tan-alpha",
    commits: 0,
    prs: 0,
    lastContrib: 0
  }, {
    username: "ayushvarma7",
    commits: 0,
    prs: 0,
    lastContrib: 0
  }, {
    username: "sid0024",
    commits: 0,
    prs: 0,
    lastContrib: 0
  }]
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},{
  "extensions": [
    ".js",
    ".json",
    ".mjs",
    ".ts"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2Nyb24vcmVmcmVzaC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21vZGVscy9wYXJ0aWNpcGFudHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb25maWcuanMiXSwibmFtZXMiOlsiTWV0ZW9yIiwibW9kdWxlIiwibGluayIsInYiLCJDcm9uSm9iIiwiUGFydGljaXBhbnRzIiwiYmFzZVRpbWVTdGFtcCIsImZldGNoIiwiSGVhZGVycyIsImRlZmF1bHQiLCJjb25maWciLCJwZXJQZXJzb24iLCJwZXJzb24iLCJ1c2VybmFtZSIsImxhc3RDb250cmliIiwiY29tbWl0cyIsInBycyIsImV2ZW50cyIsImkiLCJ0ZW1wIiwiaGVhZGVycyIsImdpdGh1YkFjY2Vzc1Rva2VuIiwianNvbiIsImxlbmd0aCIsIkRhdGUiLCJwYXJzZSIsImNyZWF0ZWRfYXQiLCJmaXJzdFB1c2hFdmVudCIsImZpbmQiLCJldmVudCIsInR5cGUiLCJuZXdDb21taXRzIiwiZmlsdGVyIiwicmVkdWNlIiwidmFsIiwiZWxlbSIsInBheWxvYWQiLCJ0ZW1wMSIsInRlbXAyIiwibmV3UFJzIiwiYWN0aW9uIiwib3V0cHV0IiwidXBkYXRlIiwiJHNldCIsImUiLCJjb25zb2xlIiwibG9nIiwidXBkYXRlRGF0YSIsInBhcnRpY2lwYW50c0xpc3QiLCJwYXJ0Iiwic3RhcnR1cCIsImNyb25UaW1lIiwib25UaWNrIiwic3RhcnQiLCJ0aW1lWm9uZSIsImV4cG9ydCIsIk1vbmdvIiwiQ29sbGVjdGlvbiIsIm1ldGhvZHMiLCJ0ZXh0IiwiRXJyb3IiLCJleHBvcnREZWZhdWx0IiwicGFydGljaXBhbnRzIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLElBQUlBLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsT0FBSjtBQUFZSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxNQUFaLEVBQW1CO0FBQUNFLFNBQU8sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFdBQU8sR0FBQ0QsQ0FBUjtBQUFVOztBQUF0QixDQUFuQixFQUEyQyxDQUEzQztBQUE4QyxJQUFJRSxZQUFKO0FBQWlCSixNQUFNLENBQUNDLElBQVAsQ0FBWSx3QkFBWixFQUFxQztBQUFDRyxjQUFZLENBQUNGLENBQUQsRUFBRztBQUFDRSxnQkFBWSxHQUFDRixDQUFiO0FBQWU7O0FBQWhDLENBQXJDLEVBQXVFLENBQXZFO0FBQTBFLElBQUlHLGFBQUo7QUFBa0JMLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0ksZUFBYSxDQUFDSCxDQUFELEVBQUc7QUFBQ0csaUJBQWEsR0FBQ0gsQ0FBZDtBQUFnQjs7QUFBbEMsQ0FBM0IsRUFBK0QsQ0FBL0Q7QUFBa0UsSUFBSUksS0FBSixFQUFVQyxPQUFWO0FBQWtCUCxNQUFNLENBQUNDLElBQVAsQ0FBWSxZQUFaLEVBQXlCO0FBQUNPLFNBQU8sQ0FBQ04sQ0FBRCxFQUFHO0FBQUNJLFNBQUssR0FBQ0osQ0FBTjtBQUFRLEdBQXBCOztBQUFxQkssU0FBTyxDQUFDTCxDQUFELEVBQUc7QUFBQ0ssV0FBTyxHQUFDTCxDQUFSO0FBQVU7O0FBQTFDLENBQXpCLEVBQXFFLENBQXJFO0FBQXdFLElBQUlPLE1BQUo7QUFBV1QsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDTyxTQUFPLENBQUNOLENBQUQsRUFBRztBQUFDTyxVQUFNLEdBQUNQLENBQVA7QUFBUzs7QUFBckIsQ0FBM0IsRUFBa0QsQ0FBbEQ7O0FBTzlZLE1BQU1RLFNBQVMsR0FBU0MsTUFBTiw2QkFBZ0I7QUFDOUIsTUFBSTtBQUFDQyxZQUFEO0FBQVdDLGVBQVg7QUFBd0JDLFdBQXhCO0FBQWlDQztBQUFqQyxNQUF3Q0osTUFBNUM7QUFDQUUsYUFBVyxHQUFHLE9BQU9BLFdBQVAsS0FBd0IsUUFBeEIsR0FBbUNBLFdBQW5DLEdBQWlELENBQS9EOztBQUNBLE1BQUk7QUFDQSxRQUFJRyxNQUFNLEdBQUcsRUFBYjs7QUFFQSxTQUFJLElBQUlDLENBQUMsR0FBRyxDQUFaLEVBQWVBLENBQUMsSUFBSSxFQUFwQixFQUF3QkEsQ0FBQyxFQUF6QixFQUNBO0FBQ0ksVUFBSUMsSUFBSSxpQkFBU1osS0FBSyx3Q0FDY00sUUFEZCwwQkFDc0NLLENBRHRDLEdBRWxCO0FBQ0lFLGVBQU8sRUFBRSxJQUFJWixPQUFKLENBQVk7QUFDakIsMkNBQTBCRSxNQUFNLENBQUNXLGlCQUFqQztBQURpQixTQUFaO0FBRGIsT0FGa0IsQ0FBZCxDQUFSO0FBUUFGLFVBQUksaUJBQVNBLElBQUksQ0FBQ0csSUFBTCxFQUFULENBQUo7QUFDQUwsWUFBTSxHQUFHLENBQUMsR0FBR0EsTUFBSixFQUFZLEdBQUdFLElBQWYsQ0FBVDtBQUNBLFVBQUdBLElBQUksQ0FBQ0ksTUFBTCxHQUFjLENBQWQsSUFBbUJDLElBQUksQ0FBQ0MsS0FBTCxDQUFXTixJQUFJLENBQUNBLElBQUksQ0FBQ0ksTUFBTCxHQUFjLENBQWYsQ0FBSixDQUFzQkcsVUFBakMsSUFBK0NaLFdBQXJFLEVBQ0E7QUFDSDs7QUFFRCxRQUFJYSxjQUFjLEdBQUdWLE1BQU0sQ0FBQ1csSUFBUCxDQUFZQyxLQUFLLElBQU1BLEtBQUssQ0FBQ0MsSUFBTixLQUFlLFdBQWhCLElBQWlDTixJQUFJLENBQUNDLEtBQUwsQ0FBV0ksS0FBSyxDQUFDSCxVQUFqQixJQUE2QnBCLGFBQXBGLENBQXJCLENBbkJBLENBcUJBOztBQUNBLFFBQUl5QixVQUFVLEdBQUdkLE1BQU0sQ0FBQ2UsTUFBUCxDQUFjSCxLQUFLLElBQUlMLElBQUksQ0FBQ0MsS0FBTCxDQUFXSSxLQUFLLENBQUNILFVBQWpCLElBQStCWixXQUF0RCxDQUFqQjtBQUNBaUIsY0FBVSxHQUFHQSxVQUFVLENBQUNSLE1BQVgsSUFBcUIsQ0FBckIsR0FBeUIsRUFBekIsR0FBOEJRLFVBQVUsQ0FBQ0UsTUFBWCxDQUFrQixDQUFDQyxHQUFELEVBQU1DLElBQU4sS0FBZTtBQUN4RSxVQUFHLE9BQU9ELEdBQVAsS0FBZ0IsUUFBbkIsRUFDQTtBQUNJLFlBQUlmLElBQUksR0FBR2dCLElBQUksQ0FBQ0wsSUFBTCxLQUFjLFdBQWQsR0FBNEJLLElBQUksQ0FBQ0MsT0FBTCxDQUFhckIsT0FBYixDQUFxQlEsTUFBakQsR0FBMEQsQ0FBckU7QUFDQSxlQUFPVyxHQUFHLEdBQUdmLElBQWI7QUFDSCxPQUpELE1BTUE7QUFDSSxZQUFJa0IsS0FBSyxHQUFHSCxHQUFHLENBQUNKLElBQUosS0FBYSxXQUFiLEdBQTJCSSxHQUFHLENBQUNFLE9BQUosQ0FBWXJCLE9BQVosQ0FBb0JRLE1BQS9DLEdBQXdELENBQXBFO0FBQ0EsWUFBSWUsS0FBSyxHQUFHSCxJQUFJLENBQUNMLElBQUwsS0FBYyxXQUFkLEdBQTRCSyxJQUFJLENBQUNDLE9BQUwsQ0FBYXJCLE9BQWIsQ0FBcUJRLE1BQWpELEdBQTBELENBQXRFO0FBQ0EsZUFBT2MsS0FBSyxHQUFHQyxLQUFmO0FBQ0g7QUFDSixLQVowQyxDQUEzQztBQWFBLFFBQUlDLE1BQU0sR0FBR3RCLE1BQU0sQ0FBQ2UsTUFBUCxDQUFjSCxLQUFLLElBQUtBLEtBQUssQ0FBQ0MsSUFBTixLQUFlLGtCQUFmLElBQXFDRCxLQUFLLENBQUNPLE9BQTNDLElBQXNEUCxLQUFLLENBQUNPLE9BQU4sQ0FBY0ksTUFBcEUsSUFBOEVYLEtBQUssQ0FBQ08sT0FBTixDQUFjSSxNQUFkLEtBQXlCLFFBQS9ILEVBQTBJakIsTUFBdko7QUFDQSxRQUFJa0IsTUFBTSxHQUFHcEMsWUFBWSxDQUFDcUMsTUFBYixDQUNUO0FBQUU3QixjQUFRLEVBQUdBO0FBQWIsS0FEUyxFQUVUO0FBQ0k4QixVQUFJLEVBQUU7QUFDRjdCLG1CQUFXLEVBQUlHLE1BQU0sQ0FBQyxDQUFELENBQU4sSUFBYU8sSUFBSSxDQUFDQyxLQUFMLENBQVlSLE1BQU0sQ0FBQyxDQUFELENBQU4sQ0FBVVMsVUFBdEIsQ0FBZixJQUFzRFosV0FBdEQsSUFBcUUsQ0FEaEY7QUFFRkMsZUFBTyxFQUFJQSxPQUFPLElBQU1BLE9BQU8sR0FBR2dCLFVBQXpCLElBQTBDLENBRmpEO0FBR0ZmLFdBQUcsRUFBSUEsR0FBRyxJQUFNQSxHQUFHLEdBQUd1QixNQUFqQixJQUE4QjtBQUhqQztBQURWLEtBRlMsQ0FBYjtBQVVILEdBL0NELENBZ0RBLE9BQU1LLENBQU4sRUFBUTtBQUNKQyxXQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0osQ0F0RGlCLENBQWxCOztBQXdEQSxNQUFNRyxVQUFVLEdBQUcsK0JBQVk7QUFDM0IsUUFBTUMsZ0JBQWdCLEdBQUczQyxZQUFZLENBQUN1QixJQUFiLENBQWtCLEVBQWxCLEVBQXNCckIsS0FBdEIsRUFBekI7QUFDQXNDLFNBQU8sQ0FBQ0MsR0FBUixDQUFZRSxnQkFBWjs7QUFDQSxPQUFJQyxJQUFKLElBQVlELGdCQUFaLEVBQ0E7QUFDSSxrQkFBTXJDLFNBQVMsQ0FBQ3FDLGdCQUFnQixDQUFDQyxJQUFELENBQWpCLENBQWY7QUFDSDtBQUNKLENBUGtCLENBQW5COztBQVNBakQsTUFBTSxDQUFDa0QsT0FBUCxDQUFlLE1BQU07QUFDakIsTUFBSTlDLE9BQUosQ0FBWTtBQUNSK0MsWUFBUSxFQUFFLGdCQURGO0FBRVI7QUFDQUMsVUFBTSxFQUFFTCxVQUhBO0FBSVJNLFNBQUssRUFBRSxJQUpDO0FBS1JDLFlBQVEsRUFBRTtBQUxGLEdBQVo7QUFPQVAsWUFBVTtBQUNiLENBVEQsRTs7Ozs7Ozs7Ozs7QUN4RUE5QyxNQUFNLENBQUNzRCxNQUFQLENBQWM7QUFBQ2xELGNBQVksRUFBQyxNQUFJQTtBQUFsQixDQUFkO0FBQStDLElBQUlMLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXFELEtBQUo7QUFBVXZELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3NELE9BQUssQ0FBQ3JELENBQUQsRUFBRztBQUFDcUQsU0FBSyxHQUFDckQsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUdsSCxNQUFNRSxZQUFZLEdBQUcsSUFBSW1ELEtBQUssQ0FBQ0MsVUFBVixDQUFxQixjQUFyQixDQUFyQjtBQUVQO0FBQ0F6RCxNQUFNLENBQUMwRCxPQUFQLENBQWU7QUFDWCx3QkFBc0JDLElBQXRCLEVBQTJCO0FBQ3ZCLFVBQU0sSUFBSTNELE1BQU0sQ0FBQzRELEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDSCxHQUhVOztBQUlYLHdCQUFzQkQsSUFBdEIsRUFBMkI7QUFDdkIsVUFBTSxJQUFJM0QsTUFBTSxDQUFDNEQsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNILEdBTlU7O0FBT1gsd0JBQXNCRCxJQUF0QixFQUEyQjtBQUN2QixVQUFNLElBQUkzRCxNQUFNLENBQUM0RCxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0gsR0FUVTs7QUFVWCx3QkFBc0JELElBQXRCLEVBQTJCO0FBQ3ZCLFVBQU0sSUFBSTNELE1BQU0sQ0FBQzRELEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDSDs7QUFaVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDTkEsSUFBSTVELE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcURGLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHVCQUFaO0FBQXFDRCxNQUFNLENBQUNDLElBQVAsQ0FBWSxnQkFBWixFOzs7Ozs7Ozs7OztBQ0FyR0QsTUFBTSxDQUFDNEQsYUFBUCxDQUFlO0FBQ1h2RCxlQUFhLEVBQUUsQ0FESjtBQUVYZSxtQkFBaUIsRUFBRSwwQ0FGUjtBQUdYeUMsY0FBWSxFQUFFLENBQ1Y7QUFDSWpELFlBQVEsRUFBRSxRQURkO0FBRUlFLFdBQU8sRUFBRSxDQUZiO0FBR0lDLE9BQUcsRUFBRSxDQUhUO0FBSUlGLGVBQVcsRUFBRTtBQUpqQixHQURVLEVBT1Y7QUFDSUQsWUFBUSxFQUFFLFdBRGQ7QUFFSUUsV0FBTyxFQUFFLENBRmI7QUFHSUMsT0FBRyxFQUFFLENBSFQ7QUFJSUYsZUFBVyxFQUFFO0FBSmpCLEdBUFUsRUFhVjtBQUNJRCxZQUFRLEVBQUUscUJBRGQ7QUFFSUUsV0FBTyxFQUFFLENBRmI7QUFHSUMsT0FBRyxFQUFFLENBSFQ7QUFJSUYsZUFBVyxFQUFFO0FBSmpCLEdBYlUsRUFtQlY7QUFDSUQsWUFBUSxFQUFFLGNBRGQ7QUFFSUUsV0FBTyxFQUFFLENBRmI7QUFHSUMsT0FBRyxFQUFFLENBSFQ7QUFJSUYsZUFBVyxFQUFFO0FBSmpCLEdBbkJVLEVBeUJWO0FBQ0lELFlBQVEsRUFBRSxXQURkO0FBRUlFLFdBQU8sRUFBRSxDQUZiO0FBR0lDLE9BQUcsRUFBRSxDQUhUO0FBSUlGLGVBQVcsRUFBRTtBQUpqQixHQXpCVSxFQStCVjtBQUNJRCxZQUFRLEVBQUUsYUFEZDtBQUVJRSxXQUFPLEVBQUUsQ0FGYjtBQUdJQyxPQUFHLEVBQUUsQ0FIVDtBQUlJRixlQUFXLEVBQUU7QUFKakIsR0EvQlUsRUFxQ1Y7QUFDSUQsWUFBUSxFQUFFLFNBRGQ7QUFFSUUsV0FBTyxFQUFFLENBRmI7QUFHSUMsT0FBRyxFQUFFLENBSFQ7QUFJSUYsZUFBVyxFQUFFO0FBSmpCLEdBckNVO0FBSEgsQ0FBZixFIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IENyb25Kb2IgfSBmcm9tICdjcm9uJztcbmltcG9ydCB7IFBhcnRpY2lwYW50cyB9IGZyb20gJy4uL21vZGVscy9wYXJ0aWNpcGFudHMnO1xuaW1wb3J0IHsgYmFzZVRpbWVTdGFtcCB9IGZyb20gJy4uLy4uL2NvbmZpZyc7XG5pbXBvcnQgZmV0Y2gsIHsgSGVhZGVycyB9IGZyb20gJ25vZGUtZmV0Y2gnO1xuaW1wb3J0IGNvbmZpZyBmcm9tICcuLi8uLi9jb25maWcnO1xuXG5jb25zdCBwZXJQZXJzb24gPSBhc3luYyBwZXJzb24gPT4ge1xuICAgIGxldCB7dXNlcm5hbWUsIGxhc3RDb250cmliLCBjb21taXRzLCBwcnN9ID0gcGVyc29uO1xuICAgIGxhc3RDb250cmliID0gdHlwZW9mKGxhc3RDb250cmliKSA9PT0gJ251bWJlcicgPyBsYXN0Q29udHJpYiA6IDA7XG4gICAgdHJ5IHtcbiAgICAgICAgbGV0IGV2ZW50cyA9IFtdO1xuXG4gICAgICAgIGZvcihsZXQgaSA9IDE7IGkgPD0gMTA7IGkrKylcbiAgICAgICAge1xuICAgICAgICAgICAgbGV0IHRlbXAgPSBhd2FpdCBmZXRjaChcbiAgICAgICAgICAgICAgICBgaHR0cHM6Ly9hcGkuZ2l0aHViLmNvbS91c2Vycy8ke3VzZXJuYW1lfS9ldmVudHM/cGFnZT0ke2l9YCxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGhlYWRlcnM6IG5ldyBIZWFkZXJzKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogYHRva2VuICR7Y29uZmlnLmdpdGh1YkFjY2Vzc1Rva2VufWBcbiAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgdGVtcCA9IGF3YWl0IHRlbXAuanNvbigpO1xuICAgICAgICAgICAgZXZlbnRzID0gWy4uLmV2ZW50cywgLi4udGVtcF07XG4gICAgICAgICAgICBpZih0ZW1wLmxlbmd0aCA+IDAgJiYgRGF0ZS5wYXJzZSh0ZW1wW3RlbXAubGVuZ3RoIC0gMV0uY3JlYXRlZF9hdCkgPCBsYXN0Q29udHJpYilcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG5cbiAgICAgICAgbGV0IGZpcnN0UHVzaEV2ZW50ID0gZXZlbnRzLmZpbmQoZXZlbnQgPT4gKChldmVudC50eXBlID09PSAnUHVzaEV2ZW50JykgJiYgKERhdGUucGFyc2UoZXZlbnQuY3JlYXRlZF9hdCk+YmFzZVRpbWVTdGFtcCkpKTtcbiAgICAgICAgXG4gICAgICAgIC8vTmV3IENvbW1pdHMgYnkgdXNlclxuICAgICAgICBsZXQgbmV3Q29tbWl0cyA9IGV2ZW50cy5maWx0ZXIoZXZlbnQgPT4gRGF0ZS5wYXJzZShldmVudC5jcmVhdGVkX2F0KSA+IGxhc3RDb250cmliKTtcbiAgICAgICAgbmV3Q29tbWl0cyA9IG5ld0NvbW1pdHMubGVuZ3RoID09IDAgPyBbXSA6IG5ld0NvbW1pdHMucmVkdWNlKCh2YWwsIGVsZW0pID0+IHtcbiAgICAgICAgICAgIGlmKHR5cGVvZih2YWwpID09PSAnbnVtYmVyJylcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBsZXQgdGVtcCA9IGVsZW0udHlwZSA9PT0gJ1B1c2hFdmVudCcgPyBlbGVtLnBheWxvYWQuY29tbWl0cy5sZW5ndGggOiAwO1xuICAgICAgICAgICAgICAgIHJldHVybiB2YWwgKyB0ZW1wO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGxldCB0ZW1wMSA9IHZhbC50eXBlID09PSAnUHVzaEV2ZW50JyA/IHZhbC5wYXlsb2FkLmNvbW1pdHMubGVuZ3RoIDogMDtcbiAgICAgICAgICAgICAgICBsZXQgdGVtcDIgPSBlbGVtLnR5cGUgPT09ICdQdXNoRXZlbnQnID8gZWxlbS5wYXlsb2FkLmNvbW1pdHMubGVuZ3RoIDogMDtcbiAgICAgICAgICAgICAgICByZXR1cm4gdGVtcDEgKyB0ZW1wMjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIGxldCBuZXdQUnMgPSBldmVudHMuZmlsdGVyKGV2ZW50ID0+IChldmVudC50eXBlID09PSAnUHVsbFJlcXVlc3RFdmVudCcgJiYgZXZlbnQucGF5bG9hZCAmJiBldmVudC5wYXlsb2FkLmFjdGlvbiAmJiBldmVudC5wYXlsb2FkLmFjdGlvbiA9PT0gJ29wZW5lZCcpKS5sZW5ndGg7XG4gICAgICAgIGxldCBvdXRwdXQgPSBQYXJ0aWNpcGFudHMudXBkYXRlKFxuICAgICAgICAgICAgeyB1c2VybmFtZSA6IHVzZXJuYW1lIH0sXG4gICAgICAgICAgICB7IFxuICAgICAgICAgICAgICAgICRzZXQ6IHtcbiAgICAgICAgICAgICAgICAgICAgbGFzdENvbnRyaWI6ICggZXZlbnRzWzBdICYmIERhdGUucGFyc2UoIGV2ZW50c1swXS5jcmVhdGVkX2F0ICkpIHx8IGxhc3RDb250cmliIHx8IDAsXG4gICAgICAgICAgICAgICAgICAgIGNvbW1pdHM6ICggY29tbWl0cyAmJiAoIGNvbW1pdHMgKyBuZXdDb21taXRzICkpIHx8IDAsXG4gICAgICAgICAgICAgICAgICAgIHByczogKCBwcnMgJiYgKCBwcnMgKyBuZXdQUnMgKSkgfHwgMFxuICAgICAgICAgICAgICAgIH0gXG4gICAgICAgICAgICB9XG4gICAgICAgICk7XG4gICAgfVxuICAgIGNhdGNoKGUpe1xuICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICB9XG59XG5cbmNvbnN0IHVwZGF0ZURhdGEgPSBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgcGFydGljaXBhbnRzTGlzdCA9IFBhcnRpY2lwYW50cy5maW5kKHt9KS5mZXRjaCgpO1xuICAgIGNvbnNvbGUubG9nKHBhcnRpY2lwYW50c0xpc3QpO1xuICAgIGZvcihwYXJ0IGluIHBhcnRpY2lwYW50c0xpc3QpXG4gICAge1xuICAgICAgICBhd2FpdCBwZXJQZXJzb24ocGFydGljaXBhbnRzTGlzdFtwYXJ0XSk7XG4gICAgfVxufVxuXG5NZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XG4gICAgbmV3IENyb25Kb2Ioe1xuICAgICAgICBjcm9uVGltZTogJzAwIDAwIDAwICogKiAqJyxcbiAgICAgICAgLy8gdXNlIHRoaXMgd3JhcHBlciBpZiB5b3Ugd2FudCB0byB3b3JrIHdpdGggbW9uZ286XG4gICAgICAgIG9uVGljazogdXBkYXRlRGF0YSxcbiAgICAgICAgc3RhcnQ6IHRydWUsXG4gICAgICAgIHRpbWVab25lOiAnQXNpYS9Lb2xrYXRhJyxcbiAgICB9KTtcbiAgICB1cGRhdGVEYXRhKCk7XG59KTsiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcblxuZXhwb3J0IGNvbnN0IFBhcnRpY2lwYW50cyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKFwicGFydGljaXBhbnRzXCIpO1xuXG4vL0RvIG5vdCBhbGxvdyB1cGRhdGlvbiBmcm9tIGNsaWVudFxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdwYXJ0aWNpcGFudHMuaW5zZXJ0Jyh0ZXh0KXtcbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcbiAgICB9LFxuICAgICdwYXJ0aWNpcGFudHMudXBkYXRlJyh0ZXh0KXtcbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcbiAgICB9LFxuICAgICdwYXJ0aWNpcGFudHMuZGVsZXRlJyh0ZXh0KXtcbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcbiAgICB9LFxuICAgICdwYXJ0aWNpcGFudHMucmVtb3ZlJyh0ZXh0KXtcbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcbiAgICB9XG59KSIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuXG5pbXBvcnQgJy4vbW9kZWxzL3BhcnRpY2lwYW50cyc7XG5cbmltcG9ydCAnLi9jcm9uL3JlZnJlc2gnOyIsImV4cG9ydCBkZWZhdWx0IHtcbiAgICBiYXNlVGltZVN0YW1wOiAwLFxuICAgIGdpdGh1YkFjY2Vzc1Rva2VuOiAnMTBmZjFlOTk4ZDIxNjkwYTBkYmMzNmY5NTY3ZTc5NzZiNDY5OTRkYicsXG4gICAgcGFydGljaXBhbnRzOiBbXG4gICAgICAgIHtcbiAgICAgICAgICAgIHVzZXJuYW1lOiBcImlzaGl0YlwiLFxuICAgICAgICAgICAgY29tbWl0czogMCxcbiAgICAgICAgICAgIHByczogMCxcbiAgICAgICAgICAgIGxhc3RDb250cmliOiAwXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICAgIHVzZXJuYW1lOiBcInBya2hyYmhzblwiLFxuICAgICAgICAgICAgY29tbWl0czogMCxcbiAgICAgICAgICAgIHByczogMCxcbiAgICAgICAgICAgIGxhc3RDb250cmliOiAwXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICAgIHVzZXJuYW1lOiBcInNpZGRoYXJ0aGJvcmRlcndhbGFcIixcbiAgICAgICAgICAgIGNvbW1pdHM6IDAsXG4gICAgICAgICAgICBwcnM6IDAsXG4gICAgICAgICAgICBsYXN0Q29udHJpYjogMFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgICB1c2VybmFtZTogXCJ5YXNoYXJtYTIzMDFcIixcbiAgICAgICAgICAgIGNvbW1pdHM6IDAsXG4gICAgICAgICAgICBwcnM6IDAsXG4gICAgICAgICAgICBsYXN0Q29udHJpYjogMFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgICB1c2VybmFtZTogXCJ0YW4tYWxwaGFcIixcbiAgICAgICAgICAgIGNvbW1pdHM6IDAsXG4gICAgICAgICAgICBwcnM6IDAsXG4gICAgICAgICAgICBsYXN0Q29udHJpYjogMFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgICB1c2VybmFtZTogXCJheXVzaHZhcm1hN1wiLFxuICAgICAgICAgICAgY29tbWl0czogMCxcbiAgICAgICAgICAgIHByczogMCxcbiAgICAgICAgICAgIGxhc3RDb250cmliOiAwXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICAgIHVzZXJuYW1lOiBcInNpZDAwMjRcIixcbiAgICAgICAgICAgIGNvbW1pdHM6IDAsXG4gICAgICAgICAgICBwcnM6IDAsXG4gICAgICAgICAgICBsYXN0Q29udHJpYjogMFxuICAgICAgICB9XG4gICAgXVxufSJdfQ==

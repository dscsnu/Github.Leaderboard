var require = meteorInstall({"server":{"cron":{"refresh.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/cron/refresh.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let CronJob;
module.link("cron", {
  CronJob(v) {
    CronJob = v;
  }

}, 1);
let Participants;
module.link("../models/participants", {
  Participants(v) {
    Participants = v;
  }

}, 2);
let baseTimeStamp;
module.link("../../config.sample.js", {
  baseTimeStamp(v) {
    baseTimeStamp = v;
  }

}, 3);
let fetch, Headers;
module.link("node-fetch", {
  default(v) {
    fetch = v;
  },

  Headers(v) {
    Headers = v;
  }

}, 4);
let config;
module.link("../../config.sample", {
  default(v) {
    config = v;
  }

}, 5);

const updateData = () => Promise.asyncApply(() => {
  const participantsList = Participants.find({}).fetch();
  participantsList.forEach(person => Promise.asyncApply(() => {
    let {
      username,
      lastContrib,
      commits,
      prs
    } = person;

    try {
      let events = [];

      for (let i = 1; i <= 10; i++) {
        let temp = Promise.await(fetch("https://api.github.com/users/".concat(username, "/events?page=").concat(i), {
          headers: new Headers({
            'Authorization': "token ".concat(config.githubAccessToken)
          })
        }));
        temp = Promise.await(temp.json());
        console.log(temp);
        events = [...events, ...temp];
        if (temp.length > 0 && Date.parse(temp[temp.length - 1].created_at) < lastContrib) break;
      }

      let firstPushEvent = events.find(event => event.type === 'PushEvent' && Date.parse(event.created_at) > baseTimeStamp); //New Commits by user

      let newCommits = events.filter(event => Date.parse(event.created_at) > lastContrib).reduce((val, elem) => {
        if (typeof val === 'number') {
          let temp = elem.type === 'PushEvent' ? elem.payload.commits.length : 0;
          return val + temp;
        } else {
          let temp1 = val.type === 'PushEvent' ? val.payload.commits.length : 0;
          let temp2 = elem.type === 'PushEvent' ? elem.payload.commits.length : 0;
          return temp1 + temp2;
        }
      });
      let newPRs = events.filter(event => event.type === 'PullRequestEvent' && event.payload && event.payload.action && event.payload.action === 'opened').length;
      let output = Participants.update({
        username: username
      }, {
        $set: {
          lastContrib: events[0] && Date.parse(events[0].created_at) || lastContrib,
          commits: commits + newCommits,
          prs: prs + newPRs
        }
      });
    } catch (e) {
      console.log(e);
    }
  }));
});

Meteor.startup(() => {
  new CronJob({
    cronTime: '00 00 00 * * *',
    // use this wrapper if you want to work with mongo:
    onTick: updateData,
    start: true,
    timeZone: 'Asia/Kolkata'
  });
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"models":{"participants.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/models/participants.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  Participants: () => Participants
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
const Participants = new Mongo.Collection("participants");
//Do not allow updation from client
Meteor.methods({
  'participants.insert'(text) {
    throw new Meteor.Error('not-authorized');
  },

  'participants.update'(text) {
    throw new Meteor.Error('not-authorized');
  },

  'participants.delete'(text) {
    throw new Meteor.Error('not-authorized');
  },

  'participants.remove'(text) {
    throw new Meteor.Error('not-authorized');
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"main.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/main.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
module.link("./models/participants");
module.link("./cron/refresh");
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"config.sample.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// config.sample.js                                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.exportDefault({
  baseTimeStamp: 0,
  githubAccessToken: 'YOUR-GITHUB-ACCESS-TOKEN-HERE'
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},{
  "extensions": [
    ".js",
    ".json",
    ".mjs",
    ".ts"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2Nyb24vcmVmcmVzaC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21vZGVscy9wYXJ0aWNpcGFudHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb25maWcuc2FtcGxlLmpzIl0sIm5hbWVzIjpbIk1ldGVvciIsIm1vZHVsZSIsImxpbmsiLCJ2IiwiQ3JvbkpvYiIsIlBhcnRpY2lwYW50cyIsImJhc2VUaW1lU3RhbXAiLCJmZXRjaCIsIkhlYWRlcnMiLCJkZWZhdWx0IiwiY29uZmlnIiwidXBkYXRlRGF0YSIsInBhcnRpY2lwYW50c0xpc3QiLCJmaW5kIiwiZm9yRWFjaCIsInBlcnNvbiIsInVzZXJuYW1lIiwibGFzdENvbnRyaWIiLCJjb21taXRzIiwicHJzIiwiZXZlbnRzIiwiaSIsInRlbXAiLCJoZWFkZXJzIiwiZ2l0aHViQWNjZXNzVG9rZW4iLCJqc29uIiwiY29uc29sZSIsImxvZyIsImxlbmd0aCIsIkRhdGUiLCJwYXJzZSIsImNyZWF0ZWRfYXQiLCJmaXJzdFB1c2hFdmVudCIsImV2ZW50IiwidHlwZSIsIm5ld0NvbW1pdHMiLCJmaWx0ZXIiLCJyZWR1Y2UiLCJ2YWwiLCJlbGVtIiwicGF5bG9hZCIsInRlbXAxIiwidGVtcDIiLCJuZXdQUnMiLCJhY3Rpb24iLCJvdXRwdXQiLCJ1cGRhdGUiLCIkc2V0IiwiZSIsInN0YXJ0dXAiLCJjcm9uVGltZSIsIm9uVGljayIsInN0YXJ0IiwidGltZVpvbmUiLCJleHBvcnQiLCJNb25nbyIsIkNvbGxlY3Rpb24iLCJtZXRob2RzIiwidGV4dCIsIkVycm9yIiwiZXhwb3J0RGVmYXVsdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxJQUFJQSxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLE9BQUo7QUFBWUgsTUFBTSxDQUFDQyxJQUFQLENBQVksTUFBWixFQUFtQjtBQUFDRSxTQUFPLENBQUNELENBQUQsRUFBRztBQUFDQyxXQUFPLEdBQUNELENBQVI7QUFBVTs7QUFBdEIsQ0FBbkIsRUFBMkMsQ0FBM0M7QUFBOEMsSUFBSUUsWUFBSjtBQUFpQkosTUFBTSxDQUFDQyxJQUFQLENBQVksd0JBQVosRUFBcUM7QUFBQ0csY0FBWSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsZ0JBQVksR0FBQ0YsQ0FBYjtBQUFlOztBQUFoQyxDQUFyQyxFQUF1RSxDQUF2RTtBQUEwRSxJQUFJRyxhQUFKO0FBQWtCTCxNQUFNLENBQUNDLElBQVAsQ0FBWSx3QkFBWixFQUFxQztBQUFDSSxlQUFhLENBQUNILENBQUQsRUFBRztBQUFDRyxpQkFBYSxHQUFDSCxDQUFkO0FBQWdCOztBQUFsQyxDQUFyQyxFQUF5RSxDQUF6RTtBQUE0RSxJQUFJSSxLQUFKLEVBQVVDLE9BQVY7QUFBa0JQLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFlBQVosRUFBeUI7QUFBQ08sU0FBTyxDQUFDTixDQUFELEVBQUc7QUFBQ0ksU0FBSyxHQUFDSixDQUFOO0FBQVEsR0FBcEI7O0FBQXFCSyxTQUFPLENBQUNMLENBQUQsRUFBRztBQUFDSyxXQUFPLEdBQUNMLENBQVI7QUFBVTs7QUFBMUMsQ0FBekIsRUFBcUUsQ0FBckU7QUFBd0UsSUFBSU8sTUFBSjtBQUFXVCxNQUFNLENBQUNDLElBQVAsQ0FBWSxxQkFBWixFQUFrQztBQUFDTyxTQUFPLENBQUNOLENBQUQsRUFBRztBQUFDTyxVQUFNLEdBQUNQLENBQVA7QUFBUzs7QUFBckIsQ0FBbEMsRUFBeUQsQ0FBekQ7O0FBT3haLE1BQU1RLFVBQVUsR0FBRywrQkFBWTtBQUMzQixRQUFNQyxnQkFBZ0IsR0FBR1AsWUFBWSxDQUFDUSxJQUFiLENBQWtCLEVBQWxCLEVBQXNCTixLQUF0QixFQUF6QjtBQUNBSyxrQkFBZ0IsQ0FBQ0UsT0FBakIsQ0FBK0JDLE1BQU4sNkJBQWdCO0FBQ3JDLFFBQUk7QUFBQ0MsY0FBRDtBQUFXQyxpQkFBWDtBQUF3QkMsYUFBeEI7QUFBaUNDO0FBQWpDLFFBQXdDSixNQUE1Qzs7QUFDQSxRQUFJO0FBQ0EsVUFBSUssTUFBTSxHQUFHLEVBQWI7O0FBRUEsV0FBSSxJQUFJQyxDQUFDLEdBQUcsQ0FBWixFQUFlQSxDQUFDLElBQUksRUFBcEIsRUFBd0JBLENBQUMsRUFBekIsRUFDQTtBQUNJLFlBQUlDLElBQUksaUJBQVNmLEtBQUssd0NBQ2NTLFFBRGQsMEJBQ3NDSyxDQUR0QyxHQUVsQjtBQUNJRSxpQkFBTyxFQUFFLElBQUlmLE9BQUosQ0FBWTtBQUNqQiw2Q0FBMEJFLE1BQU0sQ0FBQ2MsaUJBQWpDO0FBRGlCLFdBQVo7QUFEYixTQUZrQixDQUFkLENBQVI7QUFRQUYsWUFBSSxpQkFBU0EsSUFBSSxDQUFDRyxJQUFMLEVBQVQsQ0FBSjtBQUNBQyxlQUFPLENBQUNDLEdBQVIsQ0FBWUwsSUFBWjtBQUNBRixjQUFNLEdBQUcsQ0FBQyxHQUFHQSxNQUFKLEVBQVksR0FBR0UsSUFBZixDQUFUO0FBQ0EsWUFBR0EsSUFBSSxDQUFDTSxNQUFMLEdBQWMsQ0FBZCxJQUFtQkMsSUFBSSxDQUFDQyxLQUFMLENBQVdSLElBQUksQ0FBQ0EsSUFBSSxDQUFDTSxNQUFMLEdBQWMsQ0FBZixDQUFKLENBQXNCRyxVQUFqQyxJQUErQ2QsV0FBckUsRUFDQTtBQUNIOztBQUVELFVBQUllLGNBQWMsR0FBR1osTUFBTSxDQUFDUCxJQUFQLENBQVlvQixLQUFLLElBQU1BLEtBQUssQ0FBQ0MsSUFBTixLQUFlLFdBQWhCLElBQWlDTCxJQUFJLENBQUNDLEtBQUwsQ0FBV0csS0FBSyxDQUFDRixVQUFqQixJQUE2QnpCLGFBQXBGLENBQXJCLENBcEJBLENBc0JBOztBQUNBLFVBQUk2QixVQUFVLEdBQUdmLE1BQU0sQ0FBQ2dCLE1BQVAsQ0FBY0gsS0FBSyxJQUFJSixJQUFJLENBQUNDLEtBQUwsQ0FBV0csS0FBSyxDQUFDRixVQUFqQixJQUErQmQsV0FBdEQsRUFBbUVvQixNQUFuRSxDQUEwRSxDQUFDQyxHQUFELEVBQU1DLElBQU4sS0FBZTtBQUN0RyxZQUFHLE9BQU9ELEdBQVAsS0FBZ0IsUUFBbkIsRUFDQTtBQUNJLGNBQUloQixJQUFJLEdBQUdpQixJQUFJLENBQUNMLElBQUwsS0FBYyxXQUFkLEdBQTRCSyxJQUFJLENBQUNDLE9BQUwsQ0FBYXRCLE9BQWIsQ0FBcUJVLE1BQWpELEdBQTBELENBQXJFO0FBQ0EsaUJBQU9VLEdBQUcsR0FBR2hCLElBQWI7QUFDSCxTQUpELE1BTUE7QUFDSSxjQUFJbUIsS0FBSyxHQUFHSCxHQUFHLENBQUNKLElBQUosS0FBYSxXQUFiLEdBQTJCSSxHQUFHLENBQUNFLE9BQUosQ0FBWXRCLE9BQVosQ0FBb0JVLE1BQS9DLEdBQXdELENBQXBFO0FBQ0EsY0FBSWMsS0FBSyxHQUFHSCxJQUFJLENBQUNMLElBQUwsS0FBYyxXQUFkLEdBQTRCSyxJQUFJLENBQUNDLE9BQUwsQ0FBYXRCLE9BQWIsQ0FBcUJVLE1BQWpELEdBQTBELENBQXRFO0FBQ0EsaUJBQU9hLEtBQUssR0FBR0MsS0FBZjtBQUNIO0FBQ0osT0FaZ0IsQ0FBakI7QUFhQSxVQUFJQyxNQUFNLEdBQUd2QixNQUFNLENBQUNnQixNQUFQLENBQWNILEtBQUssSUFBS0EsS0FBSyxDQUFDQyxJQUFOLEtBQWUsa0JBQWYsSUFBcUNELEtBQUssQ0FBQ08sT0FBM0MsSUFBc0RQLEtBQUssQ0FBQ08sT0FBTixDQUFjSSxNQUFwRSxJQUE4RVgsS0FBSyxDQUFDTyxPQUFOLENBQWNJLE1BQWQsS0FBeUIsUUFBL0gsRUFBMEloQixNQUF2SjtBQUNBLFVBQUlpQixNQUFNLEdBQUd4QyxZQUFZLENBQUN5QyxNQUFiLENBQ1Q7QUFBRTlCLGdCQUFRLEVBQUdBO0FBQWIsT0FEUyxFQUVUO0FBQ0krQixZQUFJLEVBQUU7QUFDRjlCLHFCQUFXLEVBQUdHLE1BQU0sQ0FBQyxDQUFELENBQU4sSUFBYVMsSUFBSSxDQUFDQyxLQUFMLENBQVdWLE1BQU0sQ0FBQyxDQUFELENBQU4sQ0FBVVcsVUFBckIsQ0FBZCxJQUFtRGQsV0FEOUQ7QUFFRkMsaUJBQU8sRUFBRUEsT0FBTyxHQUFHaUIsVUFGakI7QUFHRmhCLGFBQUcsRUFBRUEsR0FBRyxHQUFHd0I7QUFIVDtBQURWLE9BRlMsQ0FBYjtBQVVILEtBL0NELENBZ0RBLE9BQU1LLENBQU4sRUFBUTtBQUNKdEIsYUFBTyxDQUFDQyxHQUFSLENBQVlxQixDQUFaO0FBQ0g7QUFDSixHQXJEd0IsQ0FBekI7QUFzREgsQ0F4RGtCLENBQW5COztBQTBEQWhELE1BQU0sQ0FBQ2lELE9BQVAsQ0FBZSxNQUFNO0FBQ2pCLE1BQUk3QyxPQUFKLENBQVk7QUFDUjhDLFlBQVEsRUFBRSxnQkFERjtBQUVSO0FBQ0FDLFVBQU0sRUFBRXhDLFVBSEE7QUFJUnlDLFNBQUssRUFBRSxJQUpDO0FBS1JDLFlBQVEsRUFBRTtBQUxGLEdBQVo7QUFPSCxDQVJELEU7Ozs7Ozs7Ozs7O0FDakVBcEQsTUFBTSxDQUFDcUQsTUFBUCxDQUFjO0FBQUNqRCxjQUFZLEVBQUMsTUFBSUE7QUFBbEIsQ0FBZDtBQUErQyxJQUFJTCxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlvRCxLQUFKO0FBQVV0RCxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNxRCxPQUFLLENBQUNwRCxDQUFELEVBQUc7QUFBQ29ELFNBQUssR0FBQ3BELENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFHbEgsTUFBTUUsWUFBWSxHQUFHLElBQUlrRCxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsY0FBckIsQ0FBckI7QUFFUDtBQUNBeEQsTUFBTSxDQUFDeUQsT0FBUCxDQUFlO0FBQ1gsd0JBQXNCQyxJQUF0QixFQUEyQjtBQUN2QixVQUFNLElBQUkxRCxNQUFNLENBQUMyRCxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0gsR0FIVTs7QUFJWCx3QkFBc0JELElBQXRCLEVBQTJCO0FBQ3ZCLFVBQU0sSUFBSTFELE1BQU0sQ0FBQzJELEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDSCxHQU5VOztBQU9YLHdCQUFzQkQsSUFBdEIsRUFBMkI7QUFDdkIsVUFBTSxJQUFJMUQsTUFBTSxDQUFDMkQsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNILEdBVFU7O0FBVVgsd0JBQXNCRCxJQUF0QixFQUEyQjtBQUN2QixVQUFNLElBQUkxRCxNQUFNLENBQUMyRCxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0g7O0FBWlUsQ0FBZixFOzs7Ozs7Ozs7OztBQ05BLElBQUkzRCxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFERixNQUFNLENBQUNDLElBQVAsQ0FBWSx1QkFBWjtBQUFxQ0QsTUFBTSxDQUFDQyxJQUFQLENBQVksZ0JBQVosRTs7Ozs7Ozs7Ozs7QUNBckdELE1BQU0sQ0FBQzJELGFBQVAsQ0FBZTtBQUNYdEQsZUFBYSxFQUFFLENBREo7QUFFWGtCLG1CQUFpQixFQUFFO0FBRlIsQ0FBZixFIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IENyb25Kb2IgfSBmcm9tICdjcm9uJztcbmltcG9ydCB7IFBhcnRpY2lwYW50cyB9IGZyb20gJy4uL21vZGVscy9wYXJ0aWNpcGFudHMnO1xuaW1wb3J0IHsgYmFzZVRpbWVTdGFtcCB9IGZyb20gJy4uLy4uL2NvbmZpZy5zYW1wbGUuanMnO1xuaW1wb3J0IGZldGNoLCB7IEhlYWRlcnMgfSBmcm9tICdub2RlLWZldGNoJztcbmltcG9ydCBjb25maWcgZnJvbSAnLi4vLi4vY29uZmlnLnNhbXBsZSc7XG5cbmNvbnN0IHVwZGF0ZURhdGEgPSBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgcGFydGljaXBhbnRzTGlzdCA9IFBhcnRpY2lwYW50cy5maW5kKHt9KS5mZXRjaCgpO1xuICAgIHBhcnRpY2lwYW50c0xpc3QuZm9yRWFjaChhc3luYyBwZXJzb24gPT4ge1xuICAgICAgICBsZXQge3VzZXJuYW1lLCBsYXN0Q29udHJpYiwgY29tbWl0cywgcHJzfSA9IHBlcnNvbjtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGxldCBldmVudHMgPSBbXTtcblxuICAgICAgICAgICAgZm9yKGxldCBpID0gMTsgaSA8PSAxMDsgaSsrKVxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGxldCB0ZW1wID0gYXdhaXQgZmV0Y2goXG4gICAgICAgICAgICAgICAgICAgIGBodHRwczovL2FwaS5naXRodWIuY29tL3VzZXJzLyR7dXNlcm5hbWV9L2V2ZW50cz9wYWdlPSR7aX1gLFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBoZWFkZXJzOiBuZXcgSGVhZGVycyh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJ0F1dGhvcml6YXRpb24nOiBgdG9rZW4gJHtjb25maWcuZ2l0aHViQWNjZXNzVG9rZW59YFxuICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgdGVtcCA9IGF3YWl0IHRlbXAuanNvbigpO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHRlbXApO1xuICAgICAgICAgICAgICAgIGV2ZW50cyA9IFsuLi5ldmVudHMsIC4uLnRlbXBdO1xuICAgICAgICAgICAgICAgIGlmKHRlbXAubGVuZ3RoID4gMCAmJiBEYXRlLnBhcnNlKHRlbXBbdGVtcC5sZW5ndGggLSAxXS5jcmVhdGVkX2F0KSA8IGxhc3RDb250cmliKVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBsZXQgZmlyc3RQdXNoRXZlbnQgPSBldmVudHMuZmluZChldmVudCA9PiAoKGV2ZW50LnR5cGUgPT09ICdQdXNoRXZlbnQnKSAmJiAoRGF0ZS5wYXJzZShldmVudC5jcmVhdGVkX2F0KT5iYXNlVGltZVN0YW1wKSkpO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICAvL05ldyBDb21taXRzIGJ5IHVzZXJcbiAgICAgICAgICAgIGxldCBuZXdDb21taXRzID0gZXZlbnRzLmZpbHRlcihldmVudCA9PiBEYXRlLnBhcnNlKGV2ZW50LmNyZWF0ZWRfYXQpID4gbGFzdENvbnRyaWIpLnJlZHVjZSgodmFsLCBlbGVtKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYodHlwZW9mKHZhbCkgPT09ICdudW1iZXInKVxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHRlbXAgPSBlbGVtLnR5cGUgPT09ICdQdXNoRXZlbnQnID8gZWxlbS5wYXlsb2FkLmNvbW1pdHMubGVuZ3RoIDogMDtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHZhbCArIHRlbXA7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGxldCB0ZW1wMSA9IHZhbC50eXBlID09PSAnUHVzaEV2ZW50JyA/IHZhbC5wYXlsb2FkLmNvbW1pdHMubGVuZ3RoIDogMDtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHRlbXAyID0gZWxlbS50eXBlID09PSAnUHVzaEV2ZW50JyA/IGVsZW0ucGF5bG9hZC5jb21taXRzLmxlbmd0aCA6IDA7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0ZW1wMSArIHRlbXAyO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgbGV0IG5ld1BScyA9IGV2ZW50cy5maWx0ZXIoZXZlbnQgPT4gKGV2ZW50LnR5cGUgPT09ICdQdWxsUmVxdWVzdEV2ZW50JyAmJiBldmVudC5wYXlsb2FkICYmIGV2ZW50LnBheWxvYWQuYWN0aW9uICYmIGV2ZW50LnBheWxvYWQuYWN0aW9uID09PSAnb3BlbmVkJykpLmxlbmd0aDtcbiAgICAgICAgICAgIGxldCBvdXRwdXQgPSBQYXJ0aWNpcGFudHMudXBkYXRlKFxuICAgICAgICAgICAgICAgIHsgdXNlcm5hbWUgOiB1c2VybmFtZSB9LFxuICAgICAgICAgICAgICAgIHsgXG4gICAgICAgICAgICAgICAgICAgICRzZXQ6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhc3RDb250cmliOiAoZXZlbnRzWzBdICYmIERhdGUucGFyc2UoZXZlbnRzWzBdLmNyZWF0ZWRfYXQpKSB8fCBsYXN0Q29udHJpYixcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbW1pdHM6IGNvbW1pdHMgKyBuZXdDb21taXRzLFxuICAgICAgICAgICAgICAgICAgICAgICAgcHJzOiBwcnMgKyBuZXdQUnNcbiAgICAgICAgICAgICAgICAgICAgfSBcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgIH1cbiAgICB9KVxufVxuXG5NZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XG4gICAgbmV3IENyb25Kb2Ioe1xuICAgICAgICBjcm9uVGltZTogJzAwIDAwIDAwICogKiAqJyxcbiAgICAgICAgLy8gdXNlIHRoaXMgd3JhcHBlciBpZiB5b3Ugd2FudCB0byB3b3JrIHdpdGggbW9uZ286XG4gICAgICAgIG9uVGljazogdXBkYXRlRGF0YSxcbiAgICAgICAgc3RhcnQ6IHRydWUsXG4gICAgICAgIHRpbWVab25lOiAnQXNpYS9Lb2xrYXRhJyxcbiAgICB9KTtcbn0pOyIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuXG5leHBvcnQgY29uc3QgUGFydGljaXBhbnRzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oXCJwYXJ0aWNpcGFudHNcIik7XG5cbi8vRG8gbm90IGFsbG93IHVwZGF0aW9uIGZyb20gY2xpZW50XG5NZXRlb3IubWV0aG9kcyh7XG4gICAgJ3BhcnRpY2lwYW50cy5pbnNlcnQnKHRleHQpe1xuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuICAgIH0sXG4gICAgJ3BhcnRpY2lwYW50cy51cGRhdGUnKHRleHQpe1xuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuICAgIH0sXG4gICAgJ3BhcnRpY2lwYW50cy5kZWxldGUnKHRleHQpe1xuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuICAgIH0sXG4gICAgJ3BhcnRpY2lwYW50cy5yZW1vdmUnKHRleHQpe1xuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuICAgIH1cbn0pIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5cbmltcG9ydCAnLi9tb2RlbHMvcGFydGljaXBhbnRzJztcblxuaW1wb3J0ICcuL2Nyb24vcmVmcmVzaCc7IiwiZXhwb3J0IGRlZmF1bHQge1xuICAgIGJhc2VUaW1lU3RhbXA6IDAsXG4gICAgZ2l0aHViQWNjZXNzVG9rZW46ICdZT1VSLUdJVEhVQi1BQ0NFU1MtVE9LRU4tSEVSRSdcbn0iXX0=
